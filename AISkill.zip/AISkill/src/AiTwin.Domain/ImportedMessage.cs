namespace AiTwin.Domain;

/// <summary>
/// 从微信、QQ 或手动粘贴文本中导入的原始聊天消息。
/// 它用于分析说话风格，不直接参与实时对话。
/// </summary>
public sealed class ImportedMessage
{
    /// <summary>
    /// 消息发送时间。某些导出格式可能没有时间，因此允许为空。
    /// </summary>
    public DateTimeOffset? Time { get; init; }

    /// <summary>
    /// 发送者昵称或备注名。
    /// </summary>
    public string Sender { get; init; } = string.Empty;

    /// <summary>
    /// 消息正文。
    /// </summary>
    public string Content { get; init; } = string.Empty;
}


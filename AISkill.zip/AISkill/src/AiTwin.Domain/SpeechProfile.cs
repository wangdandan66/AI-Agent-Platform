namespace AiTwin.Domain;

/// <summary>
/// 从历史聊天记录中提炼出来的说话风格。
/// </summary>
public sealed class SpeechProfile
{
    /// <summary>
    /// 高频语气词，例如“嗯”“哈哈”“哦”。
    /// </summary>
    public IReadOnlyList<string> Particles { get; init; } = Array.Empty<string>();

    /// <summary>
    /// 高频表情或 emoji。
    /// </summary>
    public IReadOnlyList<string> Emojis { get; init; } = Array.Empty<string>();

    /// <summary>
    /// 标点使用次数统计。
    /// </summary>
    public IReadOnlyDictionary<string, int> Punctuation { get; init; } =
        new Dictionary<string, int>();

    /// <summary>
    /// 平均消息长度。
    /// </summary>
    public double AverageLength { get; init; }

    /// <summary>
    /// 消息形态，例如短句连发或长段落。
    /// </summary>
    public string MessageShape { get; init; } = "未知";

    /// <summary>
    /// 能代表目标人物说话习惯的消息样本。
    /// </summary>
    public IReadOnlyList<string> Samples { get; init; } = Array.Empty<string>();
}


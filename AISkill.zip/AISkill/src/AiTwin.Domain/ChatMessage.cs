namespace AiTwin.Domain;

/// <summary>
/// 聊天消息实体。
/// 它只描述消息本身，不关心消息来自微信、网页还是其他渠道。
/// </summary>
public sealed class ChatMessage
{
    /// <summary>
    /// 创建一条聊天消息。
    /// </summary>
    /// <param name="role">消息角色，例如用户或 AI 分身。</param>
    /// <param name="content">消息正文。</param>
    /// <param name="time">消息产生时间。</param>
    public ChatMessage(MessageRole role, string content, DateTimeOffset time)
    {
        Role = role;
        Content = content;
        Time = time;
    }

    /// <summary>
    /// 消息在对话中的角色。
    /// </summary>
    public MessageRole Role { get; }

    /// <summary>
    /// 消息正文。
    /// </summary>
    public string Content { get; }

    /// <summary>
    /// 消息创建时间，使用 DateTimeOffset 方便保留时区信息。
    /// </summary>
    public DateTimeOffset Time { get; }
}

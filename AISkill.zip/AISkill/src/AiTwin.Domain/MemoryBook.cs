namespace AiTwin.Domain;

/// <summary>
/// AI 分身的记忆资料。
/// 这里保存事实性信息，例如共同经历、常见话题和用户补充的主观描述。
/// </summary>
public sealed class MemoryBook
{
    /// <summary>
    /// 用户手动提供的人物描述或关系背景。
    /// </summary>
    public string Description { get; init; } = string.Empty;

    /// <summary>
    /// 从聊天记录中抽出的常见关键词。
    /// </summary>
    public IReadOnlyList<string> Keywords { get; init; } = Array.Empty<string>();

    /// <summary>
    /// 典型聊天片段，用于帮助模型贴近真实表达。
    /// </summary>
    public IReadOnlyList<string> Highlights { get; init; } = Array.Empty<string>();

    /// <summary>
    /// 后续对话中的纠正记录，例如“TA 不会这样说”。
    /// </summary>
    public IReadOnlyList<string> Corrections { get; init; } = Array.Empty<string>();
}


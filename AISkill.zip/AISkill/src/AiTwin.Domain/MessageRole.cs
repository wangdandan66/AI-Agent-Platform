namespace AiTwin.Domain;

/// <summary>
/// 表示一条聊天消息在对话中的身份。
/// 这些角色会被应用层用于组织上下文，让 AI 知道哪些内容来自用户、分身或系统设定。
/// </summary>
public enum MessageRole
{
    /// <summary>
    /// 系统消息，通常用于存放人设、规则和安全边界。
    /// </summary>
    System,

    /// <summary>
    /// 用户从微信发来的消息。
    /// </summary>
    User,

    /// <summary>
    /// AI 分身生成的回复消息。
    /// </summary>
    Assistant
}

namespace AiTwin.Domain;

/// <summary>
/// 一个完整的聊天 AI 分身资料。
/// 它对应开源 Agent Skill 中的“人格 + 记忆”，但用 C# 强类型对象表达。
/// </summary>
public sealed class TwinSkill
{
    /// <summary>
    /// 分身名称。
    /// </summary>
    public string Name { get; init; } = string.Empty;

    /// <summary>
    /// 原始目标账号或人物名称。
    /// </summary>
    public string TargetName { get; init; } = string.Empty;

    /// <summary>
    /// 说话风格。
    /// </summary>
    public SpeechProfile Speech { get; init; } = new();

    /// <summary>
    /// 关系或人物记忆。
    /// </summary>
    public MemoryBook Memory { get; init; } = new();

    /// <summary>
    /// 分身必须遵守的安全规则。
    /// </summary>
    public IReadOnlyList<string> Rules { get; init; } = Array.Empty<string>();

    /// <summary>
    /// 资料生成时间。
    /// </summary>
    public DateTimeOffset CreatedAt { get; init; } = DateTimeOffset.Now;
}


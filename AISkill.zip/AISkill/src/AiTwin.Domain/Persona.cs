namespace AiTwin.Domain;

/// <summary>
/// AI 分身的人格资料。
/// 这里集中描述“像谁”“怎么说话”“不能做什么”，便于未来从数据库或配置中心加载。
/// </summary>
public sealed class Persona
{
    /// <summary>
    /// 创建一份分身人格资料。
    /// </summary>
    /// <param name="name">分身名称。</param>
    /// <param name="style">说话风格。</param>
    /// <param name="profile">身份背景。</param>
    /// <param name="rules">行为规则。</param>
    public Persona(string name, string style, string profile, IReadOnlyList<string> rules)
    {
        Name = name;
        Style = style;
        Profile = profile;
        Rules = rules;
    }

    /// <summary>
    /// 分身显示名称。
    /// </summary>
    public string Name { get; }

    /// <summary>
    /// 对话语气和表达习惯，例如温和、简洁、幽默。
    /// </summary>
    public string Style { get; }

    /// <summary>
    /// 分身的背景设定，用来帮助 AI 保持稳定的人格。
    /// </summary>
    public string Profile { get; }

    /// <summary>
    /// 分身必须遵守的规则，例如不泄露隐私、不冒充真实本人做承诺。
    /// </summary>
    public IReadOnlyList<string> Rules { get; }
}

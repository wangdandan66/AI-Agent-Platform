using System.Collections.Concurrent;
using System.Net.Http.Headers;
using System.Net.Http.Json;

var builder = WebApplication.CreateBuilder(args);

var incomingUrl = builder.Configuration["AiTwin:IncomingUrl"] ??
    "http://127.0.0.1:5000/wechat/incoming";
var token = builder.Configuration["AiTwin:Token"] ?? "change-me";
var receivedReplies = new ConcurrentQueue<BridgeReply>();

var app = builder.Build();

app.MapGet("/health", () => Results.Ok(new
{
    Status = "ok",
    Name = "AiTwin.BridgeStub",
    IncomingUrl = incomingUrl,
    ReplyCount = receivedReplies.Count
}));

app.MapPost("/send", (BridgeReply reply) =>
{
    receivedReplies.Enqueue(reply with
    {
        Time = DateTimeOffset.Now
    });

    Console.WriteLine($"收到 AI 回复 -> {reply.UserId}: {reply.Text}");

    return Results.Ok(new
    {
        Status = "received"
    });
});

app.MapGet("/messages", () => Results.Ok(receivedReplies.ToArray()));

app.MapDelete("/messages", () =>
{
    while (receivedReplies.TryDequeue(out _))
    {
    }

    return Results.Ok(new
    {
        Status = "cleared"
    });
});

app.MapPost("/simulate", async (
    BridgeIncoming message,
    CancellationToken cancellationToken) =>
{
    using var httpClient = new HttpClient();
    using var request = new HttpRequestMessage(HttpMethod.Post, incomingUrl)
    {
        Content = JsonContent.Create(message)
    };

    if (!string.IsNullOrWhiteSpace(token))
    {
        request.Headers.Authorization = new AuthenticationHeaderValue("Bearer", token);
    }

    using var response = await httpClient.SendAsync(request, cancellationToken);
    var body = await response.Content.ReadAsStringAsync(cancellationToken);

    return Results.Content(
        body,
        "application/json",
        statusCode: (int)response.StatusCode);
});

app.Run();

/// <summary>
/// 模拟微信收到的一条消息。
/// </summary>
public sealed record BridgeIncoming(string UserId, string Text);

/// <summary>
/// AI 服务发回桥接器的回复。
/// </summary>
public sealed record BridgeReply(string UserId, string Text)
{
    /// <summary>
    /// 桥接器收到回复的时间。
    /// </summary>
    public DateTimeOffset Time { get; init; }
}


using AiTwin.Domain;

namespace AiTwin.Application;

/// <summary>
/// 构建 AI 分身资料后的结果。
/// </summary>
public sealed record SkillBuildResult(
    TwinSkill Skill,
    Persona Persona,
    string SystemPrompt);


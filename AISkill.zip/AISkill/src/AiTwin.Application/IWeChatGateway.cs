namespace AiTwin.Application;

/// <summary>
/// 微信消息网关接口。
/// 真实项目中可以在基础设施层实现企业微信、公众号或客服消息通道。
/// </summary>
public interface IWeChatGateway
{
    /// <summary>
    /// 向微信用户发送回复。
    /// </summary>
    /// <param name="userId">微信用户标识。</param>
    /// <param name="text">回复内容。</param>
    /// <param name="cancellationToken">取消令牌。</param>
    Task SendAsync(string userId, string text, CancellationToken cancellationToken = default);
}

using System.Text;
using System.Text.RegularExpressions;
using AiTwin.Domain;

namespace AiTwin.Application;

/// <summary>
/// AI 分身资料构建服务。
/// 它把开源 Skill 项目的“聊天记录 → 人格/记忆”的思想改写为 C# 服务。
/// </summary>
public sealed partial class TwinSkillService
{
    private static readonly string[] DefaultRules =
    [
        "明确自己是 AI 分身，不能冒充真实本人处理现实事务。",
        "不索要密码、验证码、身份证号、银行卡号等敏感信息。",
        "不鼓励骚扰、跟踪、冒充、威胁或侵犯他人隐私。",
        "用户情绪明显低落时，优先安抚，并建议联系现实中可信赖的人。"
    ];

    /// <summary>
    /// 根据聊天记录和用户描述构建分身资料。
    /// </summary>
    /// <param name="request">构建请求。</param>
    /// <param name="messages">已解析的聊天记录。</param>
    /// <returns>分身资料、运行时人格和系统提示词。</returns>
    public SkillBuildResult Build(
        SkillBuildRequest request,
        IReadOnlyList<ImportedMessage> messages)
    {
        var targetMessages = messages
            .Where(message => IsTarget(message.Sender, request.TargetName))
            .Where(message => !string.IsNullOrWhiteSpace(message.Content))
            .ToList();

        var speech = AnalyzeSpeech(targetMessages);
        var memory = BuildMemory(request.Description, targetMessages);

        var skill = new TwinSkill
        {
            Name = request.TwinName,
            TargetName = request.TargetName,
            Speech = speech,
            Memory = memory,
            Rules = DefaultRules,
            CreatedAt = DateTimeOffset.Now
        };

        var persona = ToPersona(skill);
        var prompt = BuildSystemPrompt(skill);

        return new SkillBuildResult(skill, persona, prompt);
    }

    /// <summary>
    /// 把分身资料转换为当前聊天服务可使用的 Persona。
    /// </summary>
    public static Persona ToPersona(TwinSkill skill)
    {
        var style = new StringBuilder();
        style.Append(skill.Speech.MessageShape);

        if (skill.Speech.Particles.Count > 0)
        {
            style.Append("；常用语气词：");
            style.Append(string.Join("、", skill.Speech.Particles));
        }

        if (skill.Speech.Emojis.Count > 0)
        {
            style.Append("；常用表情：");
            style.Append(string.Join(" ", skill.Speech.Emojis));
        }

        return new Persona(
            skill.Name,
            style.ToString(),
            skill.Memory.Description,
            skill.Rules);
    }

    /// <summary>
    /// 构建给大模型使用的系统提示词。
    /// 当前 MockAi 不会真正调用模型，但接入真实模型时可以直接使用这段内容。
    /// </summary>
    public static string BuildSystemPrompt(TwinSkill skill)
    {
        var builder = new StringBuilder();
        builder.AppendLine($"你是微信聊天 AI 分身：{skill.Name}。");
        builder.AppendLine("你需要参考目标人物的说话风格和记忆资料来回复，但不能冒充真实本人处理现实事务。");
        builder.AppendLine();
        builder.AppendLine("## 安全规则");
        foreach (var rule in skill.Rules)
        {
            builder.AppendLine($"- {rule}");
        }

        builder.AppendLine();
        builder.AppendLine("## 人物/关系描述");
        builder.AppendLine(string.IsNullOrWhiteSpace(skill.Memory.Description)
            ? "[用户尚未提供描述]"
            : skill.Memory.Description);

        builder.AppendLine();
        builder.AppendLine("## 说话风格");
        builder.AppendLine($"- 消息形态：{skill.Speech.MessageShape}");
        builder.AppendLine($"- 平均长度：{skill.Speech.AverageLength:F1} 字");
        builder.AppendLine($"- 高频语气词：{JoinOrEmpty(skill.Speech.Particles)}");
        builder.AppendLine($"- 高频表情：{JoinOrEmpty(skill.Speech.Emojis)}");
        builder.AppendLine($"- 常见关键词：{JoinOrEmpty(skill.Memory.Keywords)}");

        if (skill.Speech.Samples.Count > 0)
        {
            builder.AppendLine();
            builder.AppendLine("## 代表性表达样本");
            foreach (var sample in skill.Speech.Samples.Take(8))
            {
                builder.AppendLine($"- {sample}");
            }
        }

        if (skill.Memory.Corrections.Count > 0)
        {
            builder.AppendLine();
            builder.AppendLine("## 纠正记录");
            foreach (var correction in skill.Memory.Corrections)
            {
                builder.AppendLine($"- {correction}");
            }
        }

        return builder.ToString();
    }

    private static SpeechProfile AnalyzeSpeech(IReadOnlyList<ImportedMessage> messages)
    {
        var text = string.Join(Environment.NewLine, messages.Select(message => message.Content));
        var lengths = messages.Select(message => message.Content.Length).Where(length => length > 0).ToList();
        var averageLength = lengths.Count == 0 ? 0 : lengths.Average();

        return new SpeechProfile
        {
            Particles = TopMatches(ParticleRegex(), text, 10),
            Emojis = TopMatches(EmojiRegex(), text, 10),
            Punctuation = CountPunctuation(text),
            AverageLength = Math.Round(averageLength, 1),
            MessageShape = averageLength == 0
                ? "样本不足"
                : averageLength < 20 ? "短句连发型" : "长段落表达型",
            Samples = messages
                .Select(message => message.Content.Trim())
                .Where(content => content.Length is > 0 and <= 80)
                .Distinct()
                .Take(30)
                .ToList()
        };
    }

    private static MemoryBook BuildMemory(string description, IReadOnlyList<ImportedMessage> targetMessages)
    {
        var contents = targetMessages
            .Select(message => message.Content.Trim())
            .Where(content => content.Length > 0)
            .ToList();

        return new MemoryBook
        {
            Description = description,
            Keywords = ExtractKeywords(contents),
            Highlights = contents
                .Where(content => content.Length is >= 8 and <= 120)
                .Take(20)
                .ToList(),
            Corrections = Array.Empty<string>()
        };
    }

    private static IReadOnlyList<string> ExtractKeywords(IReadOnlyList<string> contents)
    {
        var stopWords = new HashSet<string>(StringComparer.OrdinalIgnoreCase)
        {
            "我", "你", "他", "她", "它", "我们", "你们", "他们",
            "这个", "那个", "就是", "然后", "因为", "所以", "但是",
            "可以", "不是", "没有", "什么", "怎么", "还是"
        };

        return contents
            .SelectMany(content => WordRegex().Matches(content).Select(match => match.Value))
            .Where(word => word.Length >= 2 && !stopWords.Contains(word))
            .GroupBy(word => word)
            .OrderByDescending(group => group.Count())
            .ThenBy(group => group.Key)
            .Take(20)
            .Select(group => group.Key)
            .ToList();
    }

    private static IReadOnlyDictionary<string, int> CountPunctuation(string text)
    {
        return new Dictionary<string, int>
        {
            ["句号"] = text.Count(character => character == '。'),
            ["感叹号"] = text.Count(character => character is '！' or '!'),
            ["问号"] = text.Count(character => character is '？' or '?'),
            ["省略号"] = Regex.Count(text, @"\.\.\.|…"),
            ["波浪号"] = text.Count(character => character is '～' or '~')
        };
    }

    private static IReadOnlyList<string> TopMatches(Regex regex, string text, int take)
    {
        return regex.Matches(text)
            .Select(match => match.Value)
            .Where(value => !string.IsNullOrWhiteSpace(value))
            .GroupBy(value => value)
            .OrderByDescending(group => group.Count())
            .ThenBy(group => group.Key)
            .Take(take)
            .Select(group => group.Key)
            .ToList();
    }

    private static bool IsTarget(string sender, string targetName)
    {
        return sender.Contains(targetName, StringComparison.OrdinalIgnoreCase);
    }

    private static string JoinOrEmpty(IReadOnlyList<string> values)
    {
        return values.Count == 0 ? "[样本不足]" : string.Join("、", values);
    }

    [GeneratedRegex("[哈嗯哦噢嘿唉呜啊呀吧嘛呢吗么哎啦]+")]
    private static partial Regex ParticleRegex();

    [GeneratedRegex("[\\uD83C-\\uDBFF\\uDC00-\\uDFFF]+")]
    private static partial Regex EmojiRegex();

    [GeneratedRegex("[\\p{IsCJKUnifiedIdeographs}A-Za-z0-9]{2,}")]
    private static partial Regex WordRegex();
}


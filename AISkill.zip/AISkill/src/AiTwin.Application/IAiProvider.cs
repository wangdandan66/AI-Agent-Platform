using AiTwin.Domain;

namespace AiTwin.Application;

/// <summary>
/// AI 服务接口。
/// 应用层只依赖这个抽象，不直接依赖任何具体大模型 SDK。
/// </summary>
public interface IAiProvider
{
    /// <summary>
    /// 根据人格资料和历史消息生成回复。
    /// </summary>
    /// <param name="persona">当前启用的人格资料。</param>
    /// <param name="messages">最近一段聊天上下文。</param>
    /// <param name="cancellationToken">取消令牌，用于请求超时或应用关闭。</param>
    /// <returns>AI 生成的回复文本。</returns>
    Task<string> ReplyAsync(Persona persona, IReadOnlyList<ChatMessage> messages, CancellationToken cancellationToken = default);
}

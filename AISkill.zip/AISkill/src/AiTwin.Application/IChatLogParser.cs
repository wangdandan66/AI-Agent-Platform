using AiTwin.Domain;

namespace AiTwin.Application;

/// <summary>
/// 聊天记录解析接口。
/// 基础设施层可以实现微信 txt、JSON、CSV 等不同格式。
/// </summary>
public interface IChatLogParser
{
    /// <summary>
    /// 从文件中解析聊天消息。
    /// </summary>
    /// <param name="filePath">聊天记录文件路径。</param>
    /// <param name="targetName">需要模拟的目标昵称。</param>
    /// <param name="cancellationToken">取消令牌。</param>
    /// <returns>解析后的消息列表。</returns>
    Task<IReadOnlyList<ImportedMessage>> ParseAsync(
        string filePath,
        string targetName,
        CancellationToken cancellationToken = default);
}


namespace AiTwin.Application;

/// <summary>
/// 构建 AI 分身资料的请求。
/// </summary>
public sealed record SkillBuildRequest(
    string TargetName,
    string TwinName,
    string Description);


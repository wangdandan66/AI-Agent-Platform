namespace AiTwin.Application;

/// <summary>
/// 应用层收到的一次聊天请求。
/// 它把微信用户标识和消息内容打包，避免上层直接操作底层实体。
/// </summary>
public sealed record ChatRequest(string UserId, string Text);

using AiTwin.Domain;

namespace AiTwin.Application;

/// <summary>
/// 聊天记忆接口。
/// 负责保存和读取用户上下文，具体可以是内存、数据库、Redis 或向量库。
/// </summary>
public interface IChatMemory
{
    /// <summary>
    /// 读取某个用户最近的聊天记录。
    /// </summary>
    /// <param name="userId">微信用户标识。</param>
    /// <param name="take">最多返回的消息条数。</param>
    /// <param name="cancellationToken">取消令牌。</param>
    /// <returns>按时间从旧到新排列的聊天消息。</returns>
    Task<IReadOnlyList<ChatMessage>> GetAsync(string userId, int take, CancellationToken cancellationToken = default);

    /// <summary>
    /// 写入一条聊天消息。
    /// </summary>
    /// <param name="userId">微信用户标识。</param>
    /// <param name="message">需要保存的消息。</param>
    /// <param name="cancellationToken">取消令牌。</param>
    Task AddAsync(string userId, ChatMessage message, CancellationToken cancellationToken = default);
}

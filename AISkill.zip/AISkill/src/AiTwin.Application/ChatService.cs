using AiTwin.Domain;

namespace AiTwin.Application;

/// <summary>
/// 聊天应用服务。
/// 它负责编排一次完整对话：保存用户消息、读取上下文、请求 AI、保存回复、发送到微信。
/// </summary>
public sealed class ChatService
{
    private const int ContextSize = 12;

    private readonly Persona _persona;
    private readonly IAiProvider _aiProvider;
    private readonly IChatMemory _memory;
    private readonly IWeChatGateway _weChatGateway;

    /// <summary>
    /// 创建聊天服务。
    /// </summary>
    /// <param name="persona">AI 分身人格资料。</param>
    /// <param name="aiProvider">AI 回复生成器。</param>
    /// <param name="memory">聊天记忆存储。</param>
    /// <param name="weChatGateway">微信发送网关。</param>
    public ChatService(Persona persona, IAiProvider aiProvider, IChatMemory memory, IWeChatGateway weChatGateway)
    {
        _persona = persona;
        _aiProvider = aiProvider;
        _memory = memory;
        _weChatGateway = weChatGateway;
    }

    /// <summary>
    /// 处理一条来自微信的文本消息。
    /// </summary>
    /// <param name="request">聊天请求。</param>
    /// <param name="cancellationToken">取消令牌。</param>
    /// <returns>AI 分身回复。</returns>
    public async Task<ChatReply> HandleAsync(ChatRequest request, CancellationToken cancellationToken = default)
    {
        if (string.IsNullOrWhiteSpace(request.UserId))
        {
            throw new ArgumentException("用户标识不能为空。", nameof(request));
        }

        if (string.IsNullOrWhiteSpace(request.Text))
        {
            throw new ArgumentException("消息内容不能为空。", nameof(request));
        }

        var userMessage = new ChatMessage(MessageRole.User, request.Text.Trim(), DateTimeOffset.Now);
        await _memory.AddAsync(request.UserId, userMessage, cancellationToken);

        // 只取最近一段上下文，避免请求 AI 时消息过长，也让回复更聚焦。
        var history = await _memory.GetAsync(request.UserId, ContextSize, cancellationToken);
        var replyText = await _aiProvider.ReplyAsync(_persona, history, cancellationToken);

        var assistantMessage = new ChatMessage(MessageRole.Assistant, replyText, DateTimeOffset.Now);
        await _memory.AddAsync(request.UserId, assistantMessage, cancellationToken);
        await _weChatGateway.SendAsync(request.UserId, replyText, cancellationToken);

        return new ChatReply(request.UserId, replyText);
    }
}

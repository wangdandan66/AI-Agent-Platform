namespace AiTwin.Application;

/// <summary>
/// AI 分身生成的一次回复结果。
/// </summary>
public sealed record ChatReply(string UserId, string Text);

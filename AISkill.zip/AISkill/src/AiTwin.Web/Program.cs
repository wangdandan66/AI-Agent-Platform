using AiTwin.Application;
using AiTwin.Domain;
using AiTwin.Infrastructure;

var builder = WebApplication.CreateBuilder(args);
builder.Configuration.AddJsonFile(
    "appsettings.Local.json",
    optional: true,
    reloadOnChange: true);

var persona = new Persona(
    name: builder.Configuration["Persona:Name"] ?? "小艾",
    style: builder.Configuration["Persona:Style"] ?? "自然、温和、简洁，像熟悉的朋友一样回应",
    profile: builder.Configuration["Persona:Profile"] ?? "一个用于微信聊天场景的 AI 分身。",
    rules:
    [
        "不伪装成真实本人做法律、财务或医疗承诺。",
        "不主动索要密码、验证码、身份证号等敏感信息。",
        "当用户表达强烈情绪时，优先安抚并鼓励联系可信赖的人。"
    ]);

var bridgeOptions = new BridgeOptions
{
    OutboundUrl = builder.Configuration["Bridge:OutboundUrl"] ?? string.Empty,
    Token = builder.Configuration["Bridge:Token"] ?? string.Empty
};

var openAiOptions = new OpenAiOptions
{
    ApiKey = builder.Configuration["OpenAI:ApiKey"] ??
        Environment.GetEnvironmentVariable("ARK_API_KEY") ??
        Environment.GetEnvironmentVariable("DOUBAO_API_KEY") ??
        Environment.GetEnvironmentVariable("OPENAI_API_KEY") ??
        string.Empty,
    BaseUrl = builder.Configuration["OpenAI:BaseUrl"] ?? "https://api.openai.com/v1",
    Model = builder.Configuration["OpenAI:Model"] ??
        Environment.GetEnvironmentVariable("ARK_MODEL") ??
        Environment.GetEnvironmentVariable("DOUBAO_MODEL") ??
        Environment.GetEnvironmentVariable("OPENAI_MODEL") ??
        "gpt-5.4-mini",
    ApiType = builder.Configuration["OpenAI:ApiType"] ?? "responses",
    Provider = builder.Configuration["OpenAI:Provider"] ?? "openai",
    MaxOutputTokens = int.TryParse(builder.Configuration["OpenAI:MaxOutputTokens"], out var maxOutputTokens)
        ? maxOutputTokens
        : 120
};

builder.Services.AddSingleton(persona);
builder.Services.AddSingleton(bridgeOptions);
builder.Services.AddSingleton(openAiOptions);
builder.Services.AddSingleton<IChatMemory, MemoryStore>();
builder.Services.AddSingleton<IAiProvider>(provider =>
{
    var options = provider.GetRequiredService<OpenAiOptions>();

    if (string.IsNullOrWhiteSpace(options.ApiKey))
    {
        return new MockAi();
    }

    return new OpenAiProvider(
        new HttpClient
        {
            Timeout = TimeSpan.FromSeconds(90)
        },
        options);
});
builder.Services.AddSingleton<IWeChatGateway>(provider =>
{
    var options = provider.GetRequiredService<BridgeOptions>();
    var mode = builder.Configuration["Bridge:Mode"] ?? "callback";

    if (string.Equals(mode, "return-only", StringComparison.OrdinalIgnoreCase))
    {
        return new NoopWeChat();
    }

    return new BridgeWeChat(new HttpClient(), options);
});
builder.Services.AddSingleton<ChatService>();

var app = builder.Build();

app.MapGet("/health", () => Results.Ok(new
{
    Status = "ok",
    Name = "AiTwin",
    Model = openAiOptions.Model,
    Ai = string.IsNullOrWhiteSpace(openAiOptions.ApiKey) ? "mock" : openAiOptions.Provider
}));

app.MapPost("/wechat/incoming", async (
    BridgeMessage message,
    HttpRequest httpRequest,
    BridgeOptions options,
    ChatService chatService,
    CancellationToken cancellationToken) =>
{
    if (!IsAllowed(httpRequest, options.Token))
    {
        return Results.Unauthorized();
    }

    if (string.IsNullOrWhiteSpace(message.UserId) ||
        string.IsNullOrWhiteSpace(message.Text))
    {
        return Results.BadRequest(new
        {
            Error = "UserId 和 Text 不能为空。"
        });
    }

    try
    {
        var reply = await chatService.HandleAsync(
            new ChatRequest(message.UserId, message.Text),
            cancellationToken);

        return Results.Ok(reply);
    }
    catch (Exception exception)
    {
        Console.Error.WriteLine($"AI reply failed: {exception}");
        return Results.Ok(new ChatReply(
            message.UserId,
            "刚刚卡了一下。你再说一遍，我听着呢。"));
    }
});

app.Run();

/// <summary>
/// 校验桥接器访问令牌。
/// 如果配置了 Bridge:Token，请求必须携带 Authorization: Bearer {Token}。
/// </summary>
static bool IsAllowed(HttpRequest request, string token)
{
    if (string.IsNullOrWhiteSpace(token))
    {
        return true;
    }

    var header = request.Headers.Authorization.ToString();
    return string.Equals(header, $"Bearer {token}", StringComparison.Ordinal);
}

/// <summary>
/// 桥接器推送给本项目的微信消息。
/// UserId 通常是微信用户标识，Text 是收到的文本内容。
/// </summary>
public sealed record BridgeMessage(string UserId, string Text);

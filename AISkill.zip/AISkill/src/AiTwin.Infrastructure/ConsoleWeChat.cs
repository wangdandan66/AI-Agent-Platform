using AiTwin.Application;

namespace AiTwin.Infrastructure;

/// <summary>
/// 控制台版微信网关。
/// 当前用于本地演示，真实接入微信时只需要替换这个实现。
/// </summary>
public sealed class ConsoleWeChat : IWeChatGateway
{
    /// <inheritdoc />
    public Task SendAsync(string userId, string text, CancellationToken cancellationToken = default)
    {
        Console.WriteLine();
        Console.WriteLine($"发送给微信用户 {userId}：");
        Console.WriteLine(text);
        Console.WriteLine();

        return Task.CompletedTask;
    }
}

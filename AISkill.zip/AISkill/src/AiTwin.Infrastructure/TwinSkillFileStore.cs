using System.Text.Encodings.Web;
using System.Text.Json;
using AiTwin.Domain;

namespace AiTwin.Infrastructure;

/// <summary>
/// AI 分身资料文件存储。
/// 使用 JSON 保存，方便人工查看、备份和版本管理。
/// </summary>
public sealed class TwinSkillFileStore
{
    private static readonly JsonSerializerOptions JsonOptions = new()
    {
        WriteIndented = true,
        Encoder = JavaScriptEncoder.UnsafeRelaxedJsonEscaping
    };

    /// <summary>
    /// 保存分身资料。
    /// </summary>
    /// <param name="skill">需要保存的分身资料。</param>
    /// <param name="directory">保存目录。</param>
    /// <param name="cancellationToken">取消令牌。</param>
    /// <returns>保存后的文件路径。</returns>
    public async Task<string> SaveAsync(
        TwinSkill skill,
        string directory,
        CancellationToken cancellationToken = default)
    {
        Directory.CreateDirectory(directory);

        var safeName = string.Join(
            "_",
            skill.Name.Split(Path.GetInvalidFileNameChars(), StringSplitOptions.RemoveEmptyEntries));

        var filePath = Path.Combine(directory, $"{safeName}.json");
        var json = JsonSerializer.Serialize(skill, JsonOptions);
        await File.WriteAllTextAsync(filePath, json, cancellationToken);

        return filePath;
    }
}


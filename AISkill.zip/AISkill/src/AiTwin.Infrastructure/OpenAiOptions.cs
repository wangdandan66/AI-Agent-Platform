namespace AiTwin.Infrastructure;

/// <summary>
/// 兼容 OpenAI 协议的模型调用配置。
/// 可用于 OpenAI、豆包/火山方舟、DeepSeek 等兼容接口。
/// API Key 不应写进代码或提交到仓库，建议通过环境变量提供。
/// </summary>
public sealed class OpenAiOptions
{
    /// <summary>
    /// API Key。
    /// </summary>
    public string ApiKey { get; init; } = string.Empty;

    /// <summary>
    /// 模型服务基础地址。
    /// 豆包/火山方舟在线推理常用：https://ark.cn-beijing.volces.com/api/v3。
    /// </summary>
    public string BaseUrl { get; init; } = "https://api.openai.com/v1";

    /// <summary>
    /// 模型名称或推理接入点 ID。
    /// 豆包可以填写模型名，例如 doubao-seed-1-6-251015，也可以填写 ep- 开头的接入点 ID。
    /// </summary>
    public string Model { get; init; } = "gpt-5.4-mini";

    /// <summary>
    /// API 类型。
    /// responses 使用 OpenAI Responses API；chat-completions 使用 OpenAI 兼容 Chat Completions API。
    /// </summary>
    public string ApiType { get; init; } = "responses";

    /// <summary>
    /// 供应商名称，仅用于健康检查展示和日志理解。
    /// </summary>
    public string Provider { get; init; } = "openai";

    /// <summary>
    /// 单次回复最大输出长度。
    /// 微信聊天不宜过长，默认控制在短回复范围。
    /// </summary>
    public int MaxOutputTokens { get; init; } = 120;
}

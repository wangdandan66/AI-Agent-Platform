using AiTwin.Application;

namespace AiTwin.Infrastructure;

/// <summary>
/// 不执行发送动作的微信网关。
/// 当外部桥接器自己负责发送回复时，应用服务只需要返回回复文本即可。
/// </summary>
public sealed class NoopWeChat : IWeChatGateway
{
    /// <inheritdoc />
    public Task SendAsync(
        string userId,
        string text,
        CancellationToken cancellationToken = default)
    {
        return Task.CompletedTask;
    }
}


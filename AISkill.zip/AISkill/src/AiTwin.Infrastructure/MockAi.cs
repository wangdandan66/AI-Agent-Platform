using AiTwin.Application;
using AiTwin.Domain;

namespace AiTwin.Infrastructure;

/// <summary>
/// 模拟 AI 服务。
/// 它不调用外部网络，便于先验证项目分层和聊天流程是否正确。
/// </summary>
public sealed class MockAi : IAiProvider
{
    /// <inheritdoc />
    public Task<string> ReplyAsync(Persona persona, IReadOnlyList<ChatMessage> messages, CancellationToken cancellationToken = default)
    {
        var lastUserText = messages
            .LastOrDefault(message => message.Role == MessageRole.User)
            ?.Content ?? string.Empty;

        var reply = string.Join(
            Environment.NewLine,
            $"{persona.Name}：我收到啦。",
            $"你刚才说：“{lastUserText}”",
            $"我会按“{persona.Style}”的方式继续陪你聊。");

        return Task.FromResult(reply);
    }
}

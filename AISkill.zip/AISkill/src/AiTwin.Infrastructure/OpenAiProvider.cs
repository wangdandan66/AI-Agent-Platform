using System.Net.Http.Headers;
using System.Net.Http.Json;
using System.Text;
using System.Text.Json;
using AiTwin.Application;
using AiTwin.Domain;

namespace AiTwin.Infrastructure;

/// <summary>
/// 基于 OpenAI 兼容接口的真实 AI 回复生成器。
/// </summary>
public sealed class OpenAiProvider : IAiProvider
{
    private readonly HttpClient _httpClient;
    private readonly OpenAiOptions _options;
    private static readonly TimeSpan[] RetryDelays =
    [
        TimeSpan.FromMilliseconds(500),
        TimeSpan.FromSeconds(1),
        TimeSpan.FromSeconds(2)
    ];

    /// <summary>
    /// 创建 OpenAI 回复生成器。
    /// </summary>
    /// <param name="httpClient">HTTP 客户端。</param>
    /// <param name="options">OpenAI 调用配置。</param>
    public OpenAiProvider(HttpClient httpClient, OpenAiOptions options)
    {
        _httpClient = httpClient;
        _options = options;
    }

    /// <inheritdoc />
    public async Task<string> ReplyAsync(
        Persona persona,
        IReadOnlyList<ChatMessage> messages,
        CancellationToken cancellationToken = default)
    {
        if (string.IsNullOrWhiteSpace(_options.ApiKey))
        {
            throw new InvalidOperationException("未配置模型 API Key，无法调用真实模型。");
        }

        Exception? lastException = null;

        for (var attempt = 0; attempt <= RetryDelays.Length; attempt++)
        {
            try
            {
                using var request = BuildRequest(persona, messages);

                using var response = await _httpClient.SendAsync(request, cancellationToken);
                var body = await response.Content.ReadAsStringAsync(cancellationToken);

                if (!response.IsSuccessStatusCode)
                {
                    throw new InvalidOperationException($"{_options.Provider} 调用失败：{response.StatusCode} {body}");
                }

                return ExtractText(body);
            }
            catch (Exception exception) when (attempt < RetryDelays.Length)
            {
                lastException = exception;
                await Task.Delay(RetryDelays[attempt], cancellationToken);
            }
        }

        throw new InvalidOperationException($"{_options.Provider} 调用多次重试后仍失败。", lastException);
    }

    private HttpRequestMessage BuildRequest(Persona persona, IReadOnlyList<ChatMessage> messages)
    {
        // 豆包/火山方舟、DeepSeek 等服务通常兼容 Chat Completions；
        // OpenAI 新版 Responses API 也保留支持，便于以后切回。
        return string.Equals(_options.ApiType, "chat-completions", StringComparison.OrdinalIgnoreCase)
            ? BuildChatCompletionsRequest(persona, messages)
            : BuildResponsesRequest(persona, messages);
    }

    private HttpRequestMessage BuildResponsesRequest(Persona persona, IReadOnlyList<ChatMessage> messages)
    {
        var request = new HttpRequestMessage(
            HttpMethod.Post,
            $"{_options.BaseUrl.TrimEnd('/')}/responses");

        request.Headers.Authorization = new AuthenticationHeaderValue("Bearer", _options.ApiKey);
        request.Content = JsonContent.Create(new
        {
            model = _options.Model,
            instructions = BuildInstructions(persona),
            input = BuildTranscript(messages),
            max_output_tokens = _options.MaxOutputTokens
        });

        return request;
    }

    private HttpRequestMessage BuildChatCompletionsRequest(Persona persona, IReadOnlyList<ChatMessage> messages)
    {
        var request = new HttpRequestMessage(
            HttpMethod.Post,
            $"{_options.BaseUrl.TrimEnd('/')}/chat/completions");

        // OpenAI 兼容接口统一使用 Bearer Token 鉴权。
        // 火山方舟这里填 ARK_API_KEY，Model 可填模型名或 ep- 开头的推理接入点 ID。
        request.Headers.Authorization = new AuthenticationHeaderValue("Bearer", _options.ApiKey);
        request.Content = JsonContent.Create(new
        {
            model = _options.Model,
            messages = BuildChatMessages(persona, messages),
            max_tokens = _options.MaxOutputTokens,
            stream = false
        });

        return request;
    }

    private static string BuildInstructions(Persona persona)
    {
        var builder = new StringBuilder();
        builder.AppendLine($"你是微信聊天 AI 分身：{persona.Name}。");
        builder.AppendLine("你的目标是像一个自然的微信联系人一样回复，短、轻、贴近日常聊天。");
        builder.AppendLine("不要自称机器人，不要输出解释过程，不要写成客服话术。");
        builder.AppendLine();
        builder.AppendLine("## 人格背景");
        builder.AppendLine(persona.Profile);
        builder.AppendLine();
        builder.AppendLine("## 说话风格");
        builder.AppendLine(persona.Style);
        builder.AppendLine();
        builder.AppendLine("## 必须遵守");

        foreach (var rule in persona.Rules)
        {
            builder.AppendLine($"- {rule}");
        }

        builder.AppendLine("- 默认用中文回复。");
        builder.AppendLine("- 一次回复通常 1 到 3 句，除非用户明确要求详细解释。");

        return builder.ToString();
    }

    private static string BuildTranscript(IReadOnlyList<ChatMessage> messages)
    {
        var builder = new StringBuilder();
        builder.AppendLine("下面是最近的微信聊天上下文，请回复最后一条用户消息：");
        builder.AppendLine();

        foreach (var message in messages)
        {
            var role = message.Role switch
            {
                MessageRole.User => "用户",
                MessageRole.Assistant => "分身",
                _ => "系统"
            };

            builder.AppendLine($"{role}：{message.Content}");
        }

        return builder.ToString();
    }

    private static List<object> BuildChatMessages(Persona persona, IReadOnlyList<ChatMessage> messages)
    {
        // Chat Completions 需要标准 role/content 数组；
        // 人格、风格和安全规则放入 system 消息，历史微信上下文按原角色追加。
        var chatMessages = new List<object>
        {
            new
            {
                role = "system",
                content = BuildInstructions(persona)
            }
        };

        foreach (var message in messages)
        {
            var role = message.Role switch
            {
                MessageRole.Assistant => "assistant",
                MessageRole.System => "system",
                _ => "user"
            };

            chatMessages.Add(new
            {
                role,
                content = message.Content
            });
        }

        return chatMessages;
    }

    private static string ExtractText(string body)
    {
        using var document = JsonDocument.Parse(body);
        var root = document.RootElement;

        // Responses API 可能直接返回 output_text。
        if (root.TryGetProperty("output_text", out var outputText) &&
            outputText.ValueKind == JsonValueKind.String)
        {
            return outputText.GetString() ?? string.Empty;
        }

        // Chat Completions 兼容接口返回 choices[0].message.content。
        if (root.TryGetProperty("choices", out var choices) &&
            choices.ValueKind == JsonValueKind.Array)
        {
            foreach (var choice in choices.EnumerateArray())
            {
                if (choice.TryGetProperty("message", out var message) &&
                    message.TryGetProperty("content", out var content) &&
                    content.ValueKind == JsonValueKind.String)
                {
                    return content.GetString()?.Trim() ?? string.Empty;
                }
            }
        }

        if (!root.TryGetProperty("output", out var output) ||
            output.ValueKind != JsonValueKind.Array)
        {
            return string.Empty;
        }

        var parts = new List<string>();
        foreach (var item in output.EnumerateArray())
        {
            if (!item.TryGetProperty("content", out var content) ||
                content.ValueKind != JsonValueKind.Array)
            {
                continue;
            }

            foreach (var contentItem in content.EnumerateArray())
            {
                if (contentItem.TryGetProperty("text", out var text) &&
                    text.ValueKind == JsonValueKind.String)
                {
                    parts.Add(text.GetString() ?? string.Empty);
                }
            }
        }

        return string.Join(Environment.NewLine, parts).Trim();
    }
}

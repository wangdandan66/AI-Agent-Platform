using System.Collections.Concurrent;
using AiTwin.Application;
using AiTwin.Domain;

namespace AiTwin.Infrastructure;

/// <summary>
/// 基于内存的聊天记忆。
/// 适合本地演示和早期开发，生产环境建议替换成数据库或 Redis。
/// </summary>
public sealed class MemoryStore : IChatMemory
{
    private readonly ConcurrentDictionary<string, List<ChatMessage>> _messages = new();

    /// <inheritdoc />
    public Task<IReadOnlyList<ChatMessage>> GetAsync(string userId, int take, CancellationToken cancellationToken = default)
    {
        if (!_messages.TryGetValue(userId, out var messages))
        {
            return Task.FromResult<IReadOnlyList<ChatMessage>>(Array.Empty<ChatMessage>());
        }

        lock (messages)
        {
            var result = messages
                .OrderBy(message => message.Time)
                .TakeLast(take)
                .ToList();

            return Task.FromResult<IReadOnlyList<ChatMessage>>(result);
        }
    }

    /// <inheritdoc />
    public Task AddAsync(string userId, ChatMessage message, CancellationToken cancellationToken = default)
    {
        var messages = _messages.GetOrAdd(userId, _ => new List<ChatMessage>());

        lock (messages)
        {
            messages.Add(message);
        }

        return Task.CompletedTask;
    }
}

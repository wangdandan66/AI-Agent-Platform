namespace AiTwin.Infrastructure;

/// <summary>
/// 微信桥接器配置。
/// 个人微信没有官方机器人接口，因此这里使用“外部桥接器 + HTTP 回调”的方式对接。
/// </summary>
public sealed class BridgeOptions
{
    /// <summary>
    /// 桥接器接收 AI 回复的地址。
    /// 例如：http://127.0.0.1:9001/send
    /// </summary>
    public string OutboundUrl { get; init; } = string.Empty;

    /// <summary>
    /// 本项目与桥接器之间约定的访问令牌。
    /// 两边令牌一致时才处理消息，避免陌生请求直接调用接口。
    /// </summary>
    public string Token { get; init; } = string.Empty;
}


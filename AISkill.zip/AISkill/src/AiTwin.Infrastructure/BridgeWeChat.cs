using System.Net.Http.Json;
using AiTwin.Application;

namespace AiTwin.Infrastructure;

/// <summary>
/// 通过 HTTP 桥接器发送微信消息。
/// 真实微信收发由外部桥接器负责，本类只把 AI 回复投递给桥接器。
/// </summary>
public sealed class BridgeWeChat : IWeChatGateway
{
    private readonly HttpClient _httpClient;
    private readonly BridgeOptions _options;

    /// <summary>
    /// 创建微信桥接发送器。
    /// </summary>
    /// <param name="httpClient">用于调用桥接器的 HTTP 客户端。</param>
    /// <param name="options">桥接器配置。</param>
    public BridgeWeChat(HttpClient httpClient, BridgeOptions options)
    {
        _httpClient = httpClient;
        _options = options;
    }

    /// <inheritdoc />
    public async Task SendAsync(
        string userId,
        string text,
        CancellationToken cancellationToken = default)
    {
        if (string.IsNullOrWhiteSpace(_options.OutboundUrl))
        {
            throw new InvalidOperationException("未配置桥接器回复地址 Bridge:OutboundUrl。");
        }

        using var request = new HttpRequestMessage(HttpMethod.Post, _options.OutboundUrl)
        {
            Content = JsonContent.Create(new BridgeReply(userId, text))
        };

        if (!string.IsNullOrWhiteSpace(_options.Token))
        {
            request.Headers.Authorization = new("Bearer", _options.Token);
        }

        using var response = await _httpClient.SendAsync(request, cancellationToken);
        response.EnsureSuccessStatusCode();
    }

    private sealed record BridgeReply(string UserId, string Text);
}


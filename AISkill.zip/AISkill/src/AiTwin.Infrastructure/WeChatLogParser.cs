using System.Globalization;
using System.Text.Json;
using System.Text.RegularExpressions;
using AiTwin.Application;
using AiTwin.Domain;

namespace AiTwin.Infrastructure;

/// <summary>
/// 微信聊天记录解析器。
/// 支持常见 txt、JSON 和纯文本格式，便于把自己的聊天记录转换成 AI 分身资料。
/// </summary>
public sealed partial class WeChatLogParser : IChatLogParser
{
    /// <inheritdoc />
    public async Task<IReadOnlyList<ImportedMessage>> ParseAsync(
        string filePath,
        string targetName,
        CancellationToken cancellationToken = default)
    {
        if (!File.Exists(filePath))
        {
            throw new FileNotFoundException("聊天记录文件不存在。", filePath);
        }

        var extension = Path.GetExtension(filePath).ToLowerInvariant();
        return extension switch
        {
            ".json" => await ParseJsonAsync(filePath, cancellationToken),
            ".txt" => await ParseTextAsync(filePath, cancellationToken),
            _ => await ParsePlainTextAsync(filePath, targetName, cancellationToken)
        };
    }

    private static async Task<IReadOnlyList<ImportedMessage>> ParseTextAsync(
        string filePath,
        CancellationToken cancellationToken)
    {
        var lines = await File.ReadAllLinesAsync(filePath, cancellationToken);
        var messages = new List<ImportedMessage>();
        ImportedMessage? current = null;

        foreach (var rawLine in lines)
        {
            var line = rawLine.TrimEnd();
            var match = WeChatTextHeaderRegex().Match(line);

            if (match.Success)
            {
                if (current is not null)
                {
                    messages.Add(current);
                }

                current = new ImportedMessage
                {
                    Time = TryParseTime(match.Groups["time"].Value),
                    Sender = match.Groups["sender"].Value.Trim(),
                    Content = string.Empty
                };

                continue;
            }

            if (current is null)
            {
                continue;
            }

            if (!string.IsNullOrWhiteSpace(line))
            {
                current = current.WithContent(line);
            }
        }

        if (current is not null)
        {
            messages.Add(current);
        }

        return messages.Count == 0
            ? await ParsePlainTextAsync(filePath, string.Empty, cancellationToken)
            : messages;
    }

    private static async Task<IReadOnlyList<ImportedMessage>> ParseJsonAsync(
        string filePath,
        CancellationToken cancellationToken)
    {
        await using var stream = File.OpenRead(filePath);
        using var document = await JsonDocument.ParseAsync(stream, cancellationToken: cancellationToken);
        var root = document.RootElement;

        var items = root.ValueKind == JsonValueKind.Array
            ? root.EnumerateArray()
            : TryGetArray(root, "messages", "data", "items");

        var messages = new List<ImportedMessage>();
        foreach (var item in items)
        {
            messages.Add(new ImportedMessage
            {
                Time = TryParseTime(ReadString(item, "time", "timestamp", "created_at")),
                Sender = ReadString(item, "sender", "nickname", "from", "name"),
                Content = ReadString(item, "content", "message", "text", "msg")
            });
        }

        return messages;
    }

    private static async Task<IReadOnlyList<ImportedMessage>> ParsePlainTextAsync(
        string filePath,
        string targetName,
        CancellationToken cancellationToken)
    {
        var content = await File.ReadAllTextAsync(filePath, cancellationToken);
        return
        [
            new ImportedMessage
            {
                Sender = string.IsNullOrWhiteSpace(targetName) ? "未知" : targetName,
                Content = content
            }
        ];
    }

    private static IEnumerable<JsonElement> TryGetArray(JsonElement root, params string[] names)
    {
        foreach (var name in names)
        {
            if (root.TryGetProperty(name, out var value) && value.ValueKind == JsonValueKind.Array)
            {
                return value.EnumerateArray();
            }
        }

        return Array.Empty<JsonElement>();
    }

    private static string ReadString(JsonElement item, params string[] names)
    {
        foreach (var name in names)
        {
            if (item.TryGetProperty(name, out var value))
            {
                return value.ValueKind switch
                {
                    JsonValueKind.String => value.GetString() ?? string.Empty,
                    JsonValueKind.Number => value.GetRawText(),
                    _ => value.ToString()
                };
            }
        }

        return string.Empty;
    }

    private static DateTimeOffset? TryParseTime(string value)
    {
        if (string.IsNullOrWhiteSpace(value))
        {
            return null;
        }

        if (DateTimeOffset.TryParse(value, CultureInfo.CurrentCulture, DateTimeStyles.AssumeLocal, out var parsed))
        {
            return parsed;
        }

        return null;
    }

    [GeneratedRegex("^(?<time>\\d{4}-\\d{2}-\\d{2}\\s+\\d{2}:\\d{2}:\\d{2})\\s+(?<sender>.+)$")]
    private static partial Regex WeChatTextHeaderRegex();
}

internal static class ImportedMessageExtensions
{
    /// <summary>
    /// 追加多行消息内容。
    /// </summary>
    public static ImportedMessage WithContent(this ImportedMessage message, string line)
    {
        var content = string.IsNullOrWhiteSpace(message.Content)
            ? line
            : $"{message.Content}{Environment.NewLine}{line}";

        return new ImportedMessage
        {
            Time = message.Time,
            Sender = message.Sender,
            Content = content
        };
    }
}

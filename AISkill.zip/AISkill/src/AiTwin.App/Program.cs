using AiTwin.Application;
using AiTwin.Domain;
using AiTwin.Infrastructure;

if (args.Length > 0 && string.Equals(args[0], "build-skill", StringComparison.OrdinalIgnoreCase))
{
    await BuildSkillAsync(args);
    return;
}

var persona = new Persona(
    name: "小艾",
    style: "自然、温和、简洁，像熟悉的朋友一样回应",
    profile: "一个用于微信聊天场景的 AI 分身，擅长理解日常表达并给出体贴回复。",
    rules:
    [
        "不伪装成真实本人做法律、财务或医疗承诺。",
        "不主动索要密码、验证码、身份证号等敏感信息。",
        "当用户表达强烈情绪时，优先安抚并鼓励联系可信赖的人。"
    ]);

// 这里手动组装依赖，保持示例简单清楚。
// 项目变大后可以换成 Microsoft.Extensions.DependencyInjection 做依赖注入。
var service = new ChatService(
    persona,
    CreateAiProvider(),
    new MemoryStore(),
    new ConsoleWeChat());

const string userId = "wechat-demo-user";

Console.WriteLine("微信聊天 AI 分身已启动。");
Console.WriteLine("请输入消息，输入 exit 退出。");
Console.WriteLine();

while (true)
{
    Console.Write("你：");
    var text = Console.ReadLine();

    if (string.Equals(text, "exit", StringComparison.OrdinalIgnoreCase))
    {
        break;
    }

    if (string.IsNullOrWhiteSpace(text))
    {
        Console.WriteLine("消息不能为空。");
        continue;
    }

    await service.HandleAsync(new ChatRequest(userId, text));
}

Console.WriteLine("已退出。");

static IAiProvider CreateAiProvider()
{
    var apiKey =
        Environment.GetEnvironmentVariable("ARK_API_KEY") ??
        Environment.GetEnvironmentVariable("DOUBAO_API_KEY") ??
        Environment.GetEnvironmentVariable("OPENAI_API_KEY");

    if (string.IsNullOrWhiteSpace(apiKey))
    {
        return new MockAi();
    }

    return new OpenAiProvider(
        new HttpClient(),
        new OpenAiOptions
        {
            ApiKey = apiKey,
            Provider = Environment.GetEnvironmentVariable("AI_PROVIDER") ?? "doubao",
            ApiType = Environment.GetEnvironmentVariable("AI_API_TYPE") ?? "chat-completions",
            BaseUrl = Environment.GetEnvironmentVariable("AI_BASE_URL") ??
                "https://ark.cn-beijing.volces.com/api/v3",
            Model = Environment.GetEnvironmentVariable("ARK_MODEL") ??
                Environment.GetEnvironmentVariable("DOUBAO_MODEL") ??
                Environment.GetEnvironmentVariable("OPENAI_MODEL") ??
                "doubao-seed-1-6-251015"
        });
}

static async Task BuildSkillAsync(string[] args)
{
    if (args.Length < 4)
    {
        Console.WriteLine("用法：dotnet run --project src/AiTwin.App -- build-skill <聊天记录文件> <目标昵称> <分身名称> [人物描述]");
        return;
    }

    var filePath = args[1];
    var targetName = args[2];
    var twinName = args[3];
    var description = args.Length >= 5 ? args[4] : string.Empty;

    var parser = new WeChatLogParser();
    var messages = await parser.ParseAsync(filePath, targetName);

    var builder = new TwinSkillService();
    var result = builder.Build(
        new SkillBuildRequest(targetName, twinName, description),
        messages);

    var store = new TwinSkillFileStore();
    var outputPath = await store.SaveAsync(
        result.Skill,
        Path.Combine(AppContext.BaseDirectory, "twins"));

    var promptPath = Path.ChangeExtension(outputPath, ".prompt.md");
    await File.WriteAllTextAsync(promptPath, result.SystemPrompt);

    Console.WriteLine($"已分析消息数：{messages.Count}");
    Console.WriteLine($"分身资料：{outputPath}");
    Console.WriteLine($"系统提示词：{promptPath}");
}

# AI-Agent-Platform

一个基于 C# / ASP.NET Core 的 AI Agent 与微信聊天 AI 分身实验项目。当前仓库已经包含可运行的微信 AI 分身模块：通过本机 PC 微信桥接消息，调用 OpenAI 兼容模型接口生成回复，并按分层架构组织代码。

## 当前能力

- 微信聊天 AI 分身：接收微信好友/群聊文本，生成短句回复。
- OpenAI 兼容模型接口：默认按豆包/火山方舟 `chat/completions` 配置，也可切换 OpenAI、DeepSeek 等兼容服务。
- 本机 PC 微信桥接：通过 Windows UIAutomation 操作当前已登录微信窗口。
- 分身技能构建：从微信聊天记录提取说话风格、常用表达和记忆资料。
- 分层架构：领域层、应用层、基础设施层、Web 网关层相互解耦。

## 项目结构

```text
src/
  AiTwin.Domain/          # 领域层：消息、角色、人格资料、分身技能等核心对象
  AiTwin.Application/     # 应用层：聊天编排、接口契约、请求响应模型
  AiTwin.Infrastructure/  # 基础设施层：模型调用、内存记忆、微信桥接适配、聊天记录解析
  AiTwin.App/             # 控制台入口：本地模拟聊天、聊天记录生成分身资料
  AiTwin.Web/             # HTTP 网关入口：接收微信桥接消息并返回 AI 回复
  AiTwin.BridgeStub/      # 本地桥接占位服务：用于调试收发闭环
scripts/
  wechat_wxauto_bridge.py # Windows PC 微信桥接脚本
```

## 模型配置

默认按豆包/火山方舟 OpenAI 兼容接口配置：

```json
"OpenAI": {
  "ApiKey": "",
  "Provider": "doubao",
  "ApiType": "chat-completions",
  "BaseUrl": "https://ark.cn-beijing.volces.com/api/v3",
  "Model": "doubao-seed-1-6-251015",
  "MaxOutputTokens": "120"
}
```

`ApiKey` 不要提交到仓库。可以写入本地 `appsettings.Local.json`，也可以使用环境变量：

```powershell
$env:ARK_API_KEY="你的火山方舟 API Key"
$env:ARK_MODEL="doubao-seed-1-6-251015"
```

如果你在火山方舟控制台创建的是 `ep-...` 推理接入点，把 `Model` 改成对应接入点 ID 即可。没有配置 Key 时，程序会自动回退到 `MockAi`，用于先验证微信桥接流程。

## 启动 HTTP 服务

安装 .NET 10 SDK 后，在项目根目录执行：

```powershell
dotnet run --project src/AiTwin.Web --urls http://127.0.0.1:5000
```

检查服务状态：

```powershell
Invoke-RestMethod http://127.0.0.1:5000/health
```

微信桥接器收到消息后调用：

```http
POST http://127.0.0.1:5000/wechat/incoming
Authorization: Bearer change-me
Content-Type: application/json

{
  "userId": "好友或群聊标识",
  "text": "收到的微信文本"
}
```

## 接入当前登录的 PC 微信

个人微信没有官方机器人 API。本项目使用本机 Windows UI 自动化桥接当前已登录的 PC 微信，适合个人测试；不要用于骚扰、群发或违反平台规则的场景。

安装桥接依赖后，保持 PC 微信已登录、窗口可见，再启动：

```powershell
powershell -ExecutionPolicy Bypass -File scripts/Start-WxAutoBridge.ps1 -Mode current -Chat "长距离"
```

`current` 模式会先切到指定聊天，再轮询当前聊天区。桥接脚本会过滤系统时间消息、自己发出的消息，并对重复文本做去重，避免一条消息回复多次。

## 发布本机可运行包

```powershell
powershell -ExecutionPolicy Bypass -File scripts/Publish-AiTwin.ps1
```

发布目录在：

```text
release/AiTwin-WeChat
```

发布后启动服务：

```powershell
powershell -ExecutionPolicy Bypass -File release/AiTwin-WeChat/Start-AiTwin.ps1
```

启动微信桥接：

```powershell
powershell -ExecutionPolicy Bypass -File release/AiTwin-WeChat/Start-WeChatBridge.ps1 -Mode current -Chat "长距离"
```

## 从聊天记录生成分身资料

```powershell
dotnet run --project src/AiTwin.App -- build-skill "D:\聊天记录\wechat.txt" "目标昵称" "分身名称" "人物描述"
```

生成结果会保存到程序输出目录的 `twins` 文件夹：

- `{分身名称}.json`：结构化分身资料
- `{分身名称}.prompt.md`：可接入模型的系统提示词

## 后续平台方向

仓库后续可继续扩展为完整 AI Agent 平台：

- 多 Agent 协作
- 需求分析 Agent
- 任务规划 Agent
- 编码 Agent
- Review Agent
- 自动化测试 Agent
- RAG 检索与长上下文记忆
- 工作流编排与工具调用

## 安全说明

- 不要提交 `appsettings.Local.json`、日志、发布目录或 API Key。
- 已暴露过的 API Key 建议立即在平台控制台作废并重新生成。
- `Bridge:Token` 建议改成随机字符串，避免本机外的请求误触发回复。

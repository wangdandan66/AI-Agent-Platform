﻿param(
    [string]$Url = "http://127.0.0.1:5000"
)

$ErrorActionPreference = "Stop"
$root = $PSScriptRoot
$app = Join-Path $root "app\AiTwin.Web.dll"
$out = Join-Path $root "aitwin-web.out.log"
$err = Join-Path $root "aitwin-web.err.log"

Get-Process AiTwin.Web -ErrorAction SilentlyContinue | Stop-Process -ErrorAction SilentlyContinue

Start-Process -FilePath dotnet `
    -ArgumentList @($app, "--urls", $Url) `
    -WorkingDirectory (Join-Path $root "app") `
    -RedirectStandardOutput $out `
    -RedirectStandardError $err `
    -WindowStyle Hidden

Start-Sleep -Seconds 3
Invoke-RestMethod -Uri "$Url/health" | ConvertTo-Json -Compress

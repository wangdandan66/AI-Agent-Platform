﻿Get-Process AiTwin.Web -ErrorAction SilentlyContinue | Stop-Process -ErrorAction SilentlyContinue
Get-Process python -ErrorAction SilentlyContinue |
    Where-Object { $_.Path -like "*Python312*" } |
    Stop-Process -ErrorAction SilentlyContinue
Write-Host "Stopped AiTwin service and WeChat bridge."

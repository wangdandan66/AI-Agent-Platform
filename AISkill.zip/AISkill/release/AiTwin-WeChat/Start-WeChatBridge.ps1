param(
    [string]$Chat = "",
    [string]$Url = "http://127.0.0.1:5000",
    [string]$Mode = "callback"
)

$ErrorActionPreference = "Stop"
$root = $PSScriptRoot
$py312 = Join-Path $env:LOCALAPPDATA "Programs\Python\Python312\python.exe"
$python = if (Test-Path $py312) { $py312 } else { "python" }
$out = Join-Path $root "wxauto-bridge.out.log"
$err = Join-Path $root "wxauto-bridge.err.log"

Get-Process python -ErrorAction SilentlyContinue |
    Where-Object { $_.Path -like "*Python312*" } |
    Stop-Process -ErrorAction SilentlyContinue

$argsList = @(
    (Join-Path $root "scripts\wechat_wxauto_bridge.py"),
    "--mode", $Mode,
    "--incoming-url", "$Url/wechat/incoming",
    "--token", "change-me"
)

if (-not [string]::IsNullOrWhiteSpace($Chat)) {
    $argsList += @("--chat", $Chat)
}

Start-Process -FilePath $python `
    -ArgumentList $argsList `
    -WorkingDirectory $root `
    -RedirectStandardOutput $out `
    -RedirectStandardError $err `
    -WindowStyle Hidden

Start-Sleep -Seconds 5
Get-Content -Tail 80 $out
Get-Content -Tail 80 $err -ErrorAction SilentlyContinue

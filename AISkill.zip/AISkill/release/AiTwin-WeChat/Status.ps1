﻿$root = Split-Path -Parent $PSScriptRoot

Write-Host "AI service:"
try {
    Invoke-RestMethod -Uri "http://127.0.0.1:5000/health" | ConvertTo-Json -Compress
} catch {
    Write-Host $_.Exception.Message
}

Write-Host ""
Write-Host "WeChat bridge process:"
Get-Process python -ErrorAction SilentlyContinue |
    Where-Object { $_.Path -like "*Python312*" } |
    Select-Object Id, CPU, StartTime, Path

Write-Host ""
Write-Host "Bridge log:"
$log = Join-Path $root "wxauto-bridge.out.log"
if (Test-Path $log) {
    Get-Content -Tail 120 $log
}

import argparse
import json
import re
import sys
import time
import urllib.error
import urllib.request
from collections import deque


def import_wechat():
    """Import a compatible wxauto package.

    wxauto has several package names across WeChat client versions. We try the
    common open-source variants without binding the bridge to one release.
    """
    candidates = (
        ("wxautox4", "WeChat"),
        ("wxauto4", "WeChat"),
        ("wxauto", "WeChat"),
    )

    for module_name, class_name in candidates:
        try:
            module = __import__(module_name, fromlist=[class_name])
            patch_wechat_window_finder(module)
            if module_name == "wxautox4":
                patch_wxautox4_resize()
            return getattr(module, class_name), module_name
        except Exception:
            continue

    raise RuntimeError(
        "wxauto is not installed. Install Python 3.12, then run: "
        "python -m pip install wxauto requests"
    )


def patch_wechat_window_finder(module):
    """Support newer Windows WeChat windows whose class is Qt51514QWindowIcon.

    The upstream wxauto release still looks for WeChatMainWndForPC. Newer PC
    WeChat builds can expose the main window as a Qt window named "微信".
    """
    try:
        import psutil
        import win32gui
        import win32process
    except Exception:
        return

    original_find = getattr(module, "FindWindow", None)
    patched_class_name = None

    def find_window(classname=None, name=None):
        hwnd = 0

        should_try_original = classname not in (None, "WeChatMainWndForPC") or name is not None
        if original_find is not None and should_try_original:
            try:
                hwnd = original_find(classname, name)
            except Exception:
                hwnd = 0

        if hwnd and win32gui.IsWindow(hwnd):
            return hwnd

        candidates = []

        def enum_callback(candidate_hwnd, _):
            if not win32gui.IsWindow(candidate_hwnd):
                return

            title = win32gui.GetWindowText(candidate_hwnd)
            class_name = win32gui.GetClassName(candidate_hwnd)
            visible = win32gui.IsWindowVisible(candidate_hwnd)

            try:
                _, pid = win32process.GetWindowThreadProcessId(candidate_hwnd)
                process_name = psutil.Process(pid).name().lower()
            except Exception:
                process_name = ""

            if process_name == "weixin.exe" and visible and title in ("微信", "Weixin"):
                candidates.append((candidate_hwnd, class_name, title))

        win32gui.EnumWindows(enum_callback, None)

        if candidates:
            candidates.sort(
                key=lambda item: (
                    "QWindowIcon" not in item[1],
                    "ToolSaveBits" in item[1],
                    item[2] not in ("微信", "Weixin"),
                )
            )
            nonlocal patched_class_name
            patched_class_name = candidates[0][1]
            return candidates[0][0]

        return 0

    module.FindWindow = find_window

    for target_module in (module, sys.modules.get("wxauto.wxauto")):
        if target_module is None:
            continue

        try:
            target_module.FindWindow = find_window
        except Exception:
            pass

        try:
            actual_hwnd = find_window()
            wechat_class = getattr(target_module, "WeChat", None)
            uia_module = getattr(target_module, "uia", None)
            if actual_hwnd and patched_class_name and wechat_class is not None and uia_module is not None:
                print(f"Patched WeChat window class: {patched_class_name}", flush=True)
                wechat_class.UiaAPI = uia_module.WindowControl(
                    ClassName=patched_class_name,
                    searchDepth=1,
                )
        except Exception:
            pass


def patch_wxautox4_resize():
    """Disable wxautox4 auto-resize calls that can fail on newer WeChat windows."""
    try:
        import wxautox4.ui.main as ui_main
        import wxautox4.wx as wx_module
    except Exception:
        return

    patched = False

    def skip_resize(self, *args, **kwargs):
        return self

    for module in (ui_main, wx_module):
        target_class = getattr(module, "WeChatSubWnd", None)
        if target_class is None:
            continue

        for method_name in ("auto_resize", "set_window_size"):
            if hasattr(target_class, method_name):
                setattr(target_class, method_name, skip_resize)
                patched = True

    if patched:
        print("Patched wxautox4 window resize hooks.", flush=True)


def clear_wxautox4_cache():
    """Clear stale wxautox4 window cache before binding to the logged-in account."""
    try:
        import wxautox4.ui.main as ui_main

        wechat_window = getattr(ui_main, "WeChatMainWnd", None)
        if wechat_window is not None and hasattr(wechat_window, "clear_cache"):
            wechat_window.clear_cache()
            print("Cleared wxautox4 window cache.", flush=True)
    except Exception as exc:
        print(f"[warn] clear wxautox4 cache failed: {exc}", flush=True)


def find_visible_weixin_hwnd():
    try:
        import psutil
        import win32gui
        import win32process
    except Exception:
        return None

    candidates = []

    def enum_callback(candidate_hwnd, _):
        if not win32gui.IsWindow(candidate_hwnd):
            return

        title = win32gui.GetWindowText(candidate_hwnd)
        class_name = win32gui.GetClassName(candidate_hwnd)
        visible = win32gui.IsWindowVisible(candidate_hwnd)

        try:
            _, pid = win32process.GetWindowThreadProcessId(candidate_hwnd)
            process_name = psutil.Process(pid).name().lower()
        except Exception:
            process_name = ""

        if process_name == "weixin.exe" and visible and title in ("微信", "Weixin"):
            candidates.append((candidate_hwnd, class_name, title))

    win32gui.EnumWindows(enum_callback, None)
    return candidates[0][0] if candidates else None


def call_ai(incoming_url, token, user_id, text):
    payload = json.dumps(
        {
            "userId": user_id,
            "text": text,
        },
        ensure_ascii=False,
    ).encode("utf-8")

    request = urllib.request.Request(
        incoming_url,
        data=payload,
        method="POST",
        headers={
            "Content-Type": "application/json; charset=utf-8",
            "Authorization": f"Bearer {token}",
        },
    )

    with urllib.request.urlopen(request, timeout=90) as response:
        body = response.read().decode("utf-8")
        data = json.loads(body)
        return data.get("text", "")


def get_message_content(message):
    return (
        getattr(message, "content", None)
        or getattr(message, "text", None)
        or str(message)
    ).strip()


def is_from_self(message):
    attr = str(getattr(message, "attr", "")).lower()
    sender = str(getattr(message, "sender", "")).lower()
    message_type = type(message).__name__.lower()
    return "self" in attr or "self" in sender or "self" in message_type


def should_ignore_message(message, content):
    """Ignore self/system/timestamp messages so one user message gets one reply."""
    if is_from_self(message):
        return True

    attr = str(getattr(message, "attr", "")).lower()
    message_type = type(message).__name__.lower()
    if "system" in attr or "system" in message_type:
        return True

    return re.fullmatch(r"\d{1,2}:\d{2}", content) is not None


def message_identity(message):
    return (
        getattr(message, "id", None)
        or getattr(message, "msgid", None)
        or getattr(message, "hash", None)
        or str(message)
    )


def send_reply(chat, wx, who, text):
    if not text:
        return

    if hasattr(chat, "SendMsg"):
        chat.SendMsg(text)
        return

    wx.SendMsg(text, who=who)


def run_current_chat_mode(wx, chats, incoming_url, token, interval):
    requested_who = chats[0] if chats else None

    if requested_who and hasattr(wx, "ChatWith"):
        try:
            wx.ChatWith(requested_who, exact=True)
            time.sleep(1)
        except TypeError:
            wx.ChatWith(requested_who)
            time.sleep(1)
        except Exception as exc:
            print(f"[warn] switch chat failed: {requested_who}: {exc}", flush=True)

    try:
        info = wx.ChatInfo()
        who = info.get("chat_name") or info.get("name") or requested_who or "current-chat"
    except Exception:
        who = requested_who or "current-chat"

    print(f"Listening current chat: {who}", flush=True)
    seen = set()
    seen_contents = deque(maxlen=80)
    try:
        startup_messages = wx.GetAllMessage()
        pending_startup_message = None
        for message in reversed(startup_messages):
            content = get_message_content(message)
            if content and not should_ignore_message(message, content):
                pending_startup_message = message
                break

        for message in startup_messages:
            if message is pending_startup_message:
                continue

            content = get_message_content(message)
            if content:
                seen.add(f"{who}:{message_identity(message)}:{content}")
                seen_contents.append(content)
    except Exception as exc:
        print(f"[warn] seed seen messages failed: {exc}", flush=True)

    diag_count = 0

    while True:
        try:
            if diag_count < 3:
                diag_count += 1
                try:
                    print(f"[diag] ChatInfo: {wx.ChatInfo()}", flush=True)
                except Exception as diag_exc:
                    print(f"[diag] ChatInfo error: {diag_exc}", flush=True)
                try:
                    all_messages = wx.GetAllMessage()
                    print(f"[diag] AllMessage count: {len(all_messages)}", flush=True)
                    for item in all_messages[-3:]:
                        print(f"[diag] msg: {item}", flush=True)
                except Exception as diag_exc:
                    print(f"[diag] AllMessage error: {diag_exc}", flush=True)

            messages = wx.GetNewMessage()
            if not messages:
                messages = wx.GetAllMessage()[-5:]
            for message in messages:
                content = get_message_content(message)
                if not content or should_ignore_message(message, content):
                    continue

                key = f"{who}:{message_identity(message)}:{content}"
                if key in seen or content in seen_contents:
                    continue

                seen.add(key)
                seen_contents.append(content)
                print(f"[in] {who}: {content}", flush=True)
                reply = call_ai(incoming_url, token, who, content)
                print(f"[out] {who}: {reply}", flush=True)
                wx.SendMsg(reply)
        except Exception as exc:
            print(f"[error] current-chat: {exc}", flush=True)

        time.sleep(interval)


def run_callback_mode(wx, chats, incoming_url, token):
    def make_callback(who):
        def on_message(message, chat):
            content = get_message_content(message)
            if not content or should_ignore_message(message, content):
                return

            print(f"[in] {who}: {content}", flush=True)
            try:
                reply = call_ai(incoming_url, token, who, content)
                print(f"[out] {who}: {reply}", flush=True)
                send_reply(chat, wx, who, reply)
            except Exception as exc:
                print(f"[error] {who}: {exc}", flush=True)

        return on_message

    for who in chats:
        try:
            wx.AddListenChat(who, make_callback(who))
        except TypeError:
            wx.AddListenChat(nickname=who, callback=make_callback(who))

    print("wxauto bridge is listening. Keep WeChat logged in and visible.", flush=True)

    if hasattr(wx, "KeepRunning"):
        wx.KeepRunning()
        return

    while True:
        time.sleep(1)


def run_polling_mode(wx, chats, incoming_url, token, interval):
    for who in chats:
        try:
            wx.AddListenChat(who=who, savepic=False, savefile=False)
        except TypeError:
            wx.AddListenChat(nickname=who)

    print("wxauto bridge is polling. Keep WeChat logged in and visible.", flush=True)

    while True:
        try:
            messages_by_chat = wx.GetListenMessage()
            for chat, messages in messages_by_chat.items():
                who = getattr(chat, "who", None) or getattr(chat, "name", None) or str(chat)
                for message in messages:
                    content = get_message_content(message)
                    if not content or should_ignore_message(message, content):
                        continue

                    print(f"[in] {who}: {content}", flush=True)
                    reply = call_ai(incoming_url, token, who, content)
                    print(f"[out] {who}: {reply}", flush=True)
                    send_reply(chat, wx, who, reply)
        except Exception as exc:
            print(f"[error] {exc}", flush=True)

        time.sleep(interval)


def main():
    parser = argparse.ArgumentParser(description="Bridge logged-in Windows WeChat to AiTwin.")
    parser.add_argument(
        "--chat",
        action="append",
        help="WeChat contact or group name to listen to. Repeat this option for multiple chats.",
    )
    parser.add_argument(
        "--incoming-url",
        default="http://127.0.0.1:5000/wechat/incoming",
        help="AiTwin incoming message endpoint.",
    )
    parser.add_argument(
        "--token",
        default="change-me",
        help="Bearer token configured in AiTwin Bridge:Token.",
    )
    parser.add_argument(
        "--mode",
        choices=("callback", "polling", "current"),
        default="callback",
        help="wxauto API style. Use polling if callback mode is not supported by your wxauto version.",
    )
    parser.add_argument("--interval", type=float, default=1.0, help="Polling interval in seconds.")
    args = parser.parse_args()

    try:
        WeChat, module_name = import_wechat()
    except RuntimeError as exc:
        print(str(exc), file=sys.stderr)
        return 2

    print(f"Using {module_name}.", flush=True)

    if module_name == "wxauto4":
        hwnd = find_visible_weixin_hwnd()
        if hwnd:
            print(f"Using visible WeChat window hwnd={hwnd}.", flush=True)
            wx = WeChat(hwnd=hwnd)
        else:
            wx = WeChat()
    else:
        try:
            wx = WeChat(resize=False, start_listener=False)
        except TypeError:
            wx = WeChat()

    if args.mode == "current":
        run_current_chat_mode(wx, args.chat, args.incoming_url, args.token, args.interval)
    elif args.mode == "callback":
        run_callback_mode(wx, args.chat, args.incoming_url, args.token)
    else:
        run_polling_mode(wx, args.chat, args.incoming_url, args.token, args.interval)

    return 0


if __name__ == "__main__":
    raise SystemExit(main())

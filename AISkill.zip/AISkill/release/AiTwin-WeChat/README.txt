﻿# AiTwin-WeChat Release

## Start

1. Keep PC WeChat logged in and visible.
2. Start AI service:

powershell -ExecutionPolicy Bypass -File .\Start-AiTwin.ps1

3. Start WeChat bridge, example chat name:

powershell -ExecutionPolicy Bypass -File .\Start-WeChatBridge.ps1 -Chat "chat-name"

## Status

powershell -ExecutionPolicy Bypass -File .\Status.ps1

## Stop

powershell -ExecutionPolicy Bypass -File .\Stop-All.ps1

## Config

Private local config: app\appsettings.Local.json
Do not share this file. It contains your API key.

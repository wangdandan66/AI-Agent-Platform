import argparse
import json
import sys
import urllib.request

from wechat_auto import WxAuto


def call_ai(incoming_url, token, user_id, text):
    payload = json.dumps(
        {
            "userId": user_id,
            "text": text,
        },
        ensure_ascii=False,
    ).encode("utf-8")

    request = urllib.request.Request(
        incoming_url,
        data=payload,
        method="POST",
        headers={
            "Content-Type": "application/json; charset=utf-8",
            "Authorization": f"Bearer {token}",
        },
    )

    with urllib.request.urlopen(request, timeout=90) as response:
        body = response.read().decode("utf-8")
        data = json.loads(body)
        return data.get("text", "")


def main():
    parser = argparse.ArgumentParser(description="Bridge logged-in PC WeChat to AiTwin via wechat-pc-auto.")
    parser.add_argument("--chat", action="append", help="Allowed chat name. Repeat for multiple chats.")
    parser.add_argument("--incoming-url", default="http://127.0.0.1:5000/wechat/incoming")
    parser.add_argument("--token", default="change-me")
    parser.add_argument("--interval", type=float, default=2.0)
    args = parser.parse_args()

    allowed = set(args.chat or [])
    wx = WxAuto()

    if not wx.load_wechat():
        print("Failed to activate WeChat. Please unlock and show the WeChat window.", file=sys.stderr)
        return 2

    print("wechat-pc-auto bridge is listening for unread messages.", flush=True)
    if allowed:
        print("Allowed chats: " + ", ".join(allowed), flush=True)

    def on_message(name, content, _wx):
        if allowed and name not in allowed:
            print(f"[skip] {name}: {content}", flush=True)
            return None

        print(f"[in] {name}: {content}", flush=True)
        try:
            reply = call_ai(args.incoming_url, args.token, name, content)
            print(f"[out] {name}: {reply}", flush=True)
            return reply
        except Exception as exc:
            print(f"[error] {name}: {exc}", flush=True)
            return None

    wx.listen(on_message, interval=args.interval)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())


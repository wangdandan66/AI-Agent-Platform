param(
    [string]$Chat = "",
    [double]$Interval = 2.0
)

$ErrorActionPreference = "Stop"

$py312 = Join-Path $env:LOCALAPPDATA "Programs\Python\Python312\python.exe"
$python = if (Test-Path $py312) { $py312 } else { "python" }

$argsList = @(
    "scripts\wechat_pc_auto_bridge.py",
    "--incoming-url", "http://127.0.0.1:5000/wechat/incoming",
    "--token", "change-me",
    "--interval", "$Interval"
)

if (-not [string]::IsNullOrWhiteSpace($Chat)) {
    $argsList += @("--chat", $Chat)
}

& $python @argsList


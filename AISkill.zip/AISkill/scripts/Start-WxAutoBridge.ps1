param(
    [Parameter(Mandatory = $true)]
    [string]$Chat,

    [string]$Mode = "current"
)

$ErrorActionPreference = "Stop"

$py312 = Join-Path $env:LOCALAPPDATA "Programs\Python\Python312\python.exe"
$python = if (Test-Path $py312) { $py312 } else { "python" }

$version = & $python --version 2>&1
if ($version -match "3\.13") {
    Write-Host "Current Python is $version"
    Write-Host "wxauto needs Python 3.9-3.12. Please install Python 3.12 and run again."
    exit 1
}

Write-Host "Starting wxauto bridge for chat: $Chat"
Write-Host "Keep Windows WeChat logged in, unlocked, and do not minimize it while testing."

& $python scripts\wechat_wxauto_bridge.py `
    --chat $Chat `
    --mode $Mode `
    --incoming-url "http://127.0.0.1:5000/wechat/incoming" `
    --token "change-me"

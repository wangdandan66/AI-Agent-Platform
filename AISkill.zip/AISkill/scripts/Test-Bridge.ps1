param(
    [string]$UserId = "wechat-test-user",
    [string]$Text = "hello"
)

$utf8 = New-Object System.Text.UTF8Encoding
[Console]::OutputEncoding = $utf8
$OutputEncoding = $utf8

$body = @{
    userId = $UserId
    text = $Text
} | ConvertTo-Json -Compress

$bytes = [System.Text.Encoding]::UTF8.GetBytes($body)

$request = @{
    Uri = "http://127.0.0.1:9001/simulate"
    Method = "Post"
    ContentType = "application/json; charset=utf-8"
    Body = $bytes
}

$response = Invoke-RestMethod @request

Write-Host "AI reply:"
Write-Host $response.text

param(
    [Parameter(Mandatory = $true)]
    [string]$Code
)

$ErrorActionPreference = "Stop"

$exe = Join-Path $env:LOCALAPPDATA "Programs\Python\Python312\Scripts\wxautox4.exe"
if (-not (Test-Path $exe)) {
    throw "wxautox4.exe not found. Install wxautox4 first."
}

& $exe -a $Code


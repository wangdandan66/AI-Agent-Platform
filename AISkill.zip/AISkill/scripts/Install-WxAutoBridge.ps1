$ErrorActionPreference = "Stop"

$py312 = Join-Path $env:LOCALAPPDATA "Programs\Python\Python312\python.exe"
$python = if (Test-Path $py312) { $py312 } else { "python" }

$version = & $python --version 2>&1
Write-Host "Python: $version"

if ($version -match "3\.13") {
    Write-Host "wxauto usually supports Python 3.9-3.12. Python 3.13 may not find a compatible package."
    Write-Host "Install Python 3.12 from https://www.python.org/downloads/release/python-31210/"
    Write-Host "Then run this script again from a new PowerShell window."
    exit 1
}

& $python -m pip install --upgrade pip
& $python -m pip install --upgrade git+https://github.com/cluic/wxauto.git requests

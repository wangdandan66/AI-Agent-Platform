$ErrorActionPreference = "Stop"

$root = Split-Path -Parent $PSScriptRoot
$releaseRoot = Join-Path $root "release\AiTwin-WeChat"
$webRelease = Join-Path $releaseRoot "app"

if (Test-Path $releaseRoot) {
    Remove-Item -LiteralPath $releaseRoot -Recurse -Force
}

New-Item -ItemType Directory -Force -Path $webRelease | Out-Null

dotnet publish (Join-Path $root "src\AiTwin.Web\AiTwin.Web.csproj") `
    -c Release `
    -r win-x64 `
    --self-contained false `
    -o $webRelease

New-Item -ItemType Directory -Force -Path (Join-Path $releaseRoot "scripts") | Out-Null

Copy-Item -LiteralPath (Join-Path $root "scripts\wechat_wxauto_bridge.py") -Destination (Join-Path $releaseRoot "scripts\wechat_wxauto_bridge.py")

@'
param(
    [string]$Url = "http://127.0.0.1:5000"
)

$ErrorActionPreference = "Stop"
$root = $PSScriptRoot
$app = Join-Path $root "app\AiTwin.Web.dll"
$out = Join-Path $root "aitwin-web.out.log"
$err = Join-Path $root "aitwin-web.err.log"

Get-Process AiTwin.Web -ErrorAction SilentlyContinue | Stop-Process -ErrorAction SilentlyContinue

Start-Process -FilePath dotnet `
    -ArgumentList @($app, "--urls", $Url) `
    -WorkingDirectory (Join-Path $root "app") `
    -RedirectStandardOutput $out `
    -RedirectStandardError $err `
    -WindowStyle Hidden

Start-Sleep -Seconds 3
Invoke-RestMethod -Uri "$Url/health" | ConvertTo-Json -Compress
'@ | Set-Content -LiteralPath (Join-Path $releaseRoot "Start-AiTwin.ps1") -Encoding UTF8

@'
param(
    [string]$Chat = "",

    [string]$Url = "http://127.0.0.1:5000",

    [string]$Mode = "current"
)

$ErrorActionPreference = "Stop"
$root = $PSScriptRoot
$py312 = Join-Path $env:LOCALAPPDATA "Programs\Python\Python312\python.exe"
$python = if (Test-Path $py312) { $py312 } else { "python" }
$out = Join-Path $root "wxauto-bridge.out.log"
$err = Join-Path $root "wxauto-bridge.err.log"

Get-Process python -ErrorAction SilentlyContinue |
    Where-Object { $_.Path -like "*Python312*" } |
    Stop-Process -ErrorAction SilentlyContinue

Start-Process -FilePath $python `
    -ArgumentList @(
        (Join-Path $root "scripts\wechat_wxauto_bridge.py"),
        "--mode", $Mode,
        "--chat", $Chat,
        "--incoming-url", "$Url/wechat/incoming",
        "--token", "change-me"
    ) `
    -WorkingDirectory $root `
    -RedirectStandardOutput $out `
    -RedirectStandardError $err `
    -WindowStyle Hidden

Start-Sleep -Seconds 5
Get-Content -Tail 80 $out
Get-Content -Tail 80 $err -ErrorAction SilentlyContinue
'@ | Set-Content -LiteralPath (Join-Path $releaseRoot "Start-WeChatBridge.ps1") -Encoding UTF8

@'
$root = Split-Path -Parent $PSScriptRoot

Write-Host "AI service:"
try {
    Invoke-RestMethod -Uri "http://127.0.0.1:5000/health" | ConvertTo-Json -Compress
} catch {
    Write-Host $_.Exception.Message
}

Write-Host ""
Write-Host "WeChat bridge process:"
Get-Process python -ErrorAction SilentlyContinue |
    Where-Object { $_.Path -like "*Python312*" } |
    Select-Object Id, CPU, StartTime, Path

Write-Host ""
Write-Host "Bridge log:"
$log = Join-Path $root "wxauto-bridge.out.log"
if (Test-Path $log) {
    Get-Content -Tail 120 $log
}
'@ | Set-Content -LiteralPath (Join-Path $releaseRoot "Status.ps1") -Encoding UTF8

@'
Get-Process AiTwin.Web -ErrorAction SilentlyContinue | Stop-Process -ErrorAction SilentlyContinue
Get-Process python -ErrorAction SilentlyContinue |
    Where-Object { $_.Path -like "*Python312*" } |
    Stop-Process -ErrorAction SilentlyContinue
Write-Host "Stopped AiTwin service and WeChat bridge."
'@ | Set-Content -LiteralPath (Join-Path $releaseRoot "Stop-All.ps1") -Encoding UTF8

@'
{
  "Bridge": {
    "Mode": "return-only",
    "OutboundUrl": "http://127.0.0.1:9001/send",
    "Token": "change-me"
  },
  "OpenAI": {
    "ApiKey": "put-your-doubao-or-ark-key-here",
    "Provider": "doubao",
    "ApiType": "chat-completions",
    "BaseUrl": "https://ark.cn-beijing.volces.com/api/v3",
    "Model": "doubao-seed-1-6-251015",
    "MaxOutputTokens": "120"
  },
  "Persona": {
    "Name": "AiTwin",
    "Style": "Natural, warm, concise WeChat style",
    "Profile": "A WeChat AI twin for daily chat."
  }
}
'@ | Set-Content -LiteralPath (Join-Path $releaseRoot "app\appsettings.Local.template.json") -Encoding UTF8

$localConfig = Join-Path $root "src\AiTwin.Web\appsettings.Local.json"
if (Test-Path $localConfig) {
    Copy-Item -LiteralPath $localConfig -Destination (Join-Path $releaseRoot "app\appsettings.Local.json")
}

$readme = @(
    "# AiTwin-WeChat Release",
    "",
    "## Start",
    "",
    "1. Keep PC WeChat logged in and visible.",
    "2. Start AI service:",
    "",
    "powershell -ExecutionPolicy Bypass -File .\Start-AiTwin.ps1",
    "",
    "3. Start WeChat bridge, example chat name:",
    "",
    "powershell -ExecutionPolicy Bypass -File .\Start-WeChatBridge.ps1 -Mode current -Chat `"chat-name`"",
    "",
    "## Status",
    "",
    "powershell -ExecutionPolicy Bypass -File .\Status.ps1",
    "",
    "## Stop",
    "",
    "powershell -ExecutionPolicy Bypass -File .\Stop-All.ps1",
    "",
    "## Config",
    "",
    "Private local config: app\appsettings.Local.json",
    "Do not share this file. It contains your API key.",
    "Doubao/Volcengine Ark uses OpenAI-compatible chat completions:",
    "BaseUrl: https://ark.cn-beijing.volces.com/api/v3",
    "ApiType: chat-completions"
)
$readme | Set-Content -LiteralPath (Join-Path $releaseRoot "README.txt") -Encoding UTF8

Write-Host "Published to: $releaseRoot"
